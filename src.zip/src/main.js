import 'babel-polyfill';
import $ from 'jquery';

import Header from './components/Header/Header'
import ProductGallery from './components/ProductGallery/ProductGallery'


$(document).ready(() => {
  // PUT LOADERS HERE
  Header.init()
  ProductGallery.init()
});
